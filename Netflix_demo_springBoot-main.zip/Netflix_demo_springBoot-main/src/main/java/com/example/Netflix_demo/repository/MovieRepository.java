package com.example.Netflix_demo.repository;

import com.example.Netflix_demo.model.Movie;
import org.springframework.data.repository.CrudRepository;

public interface MovieRepository extends CrudRepository<Movie, String> {}






