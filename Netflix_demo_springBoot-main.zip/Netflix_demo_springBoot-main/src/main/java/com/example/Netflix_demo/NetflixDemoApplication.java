package com.example.Netflix_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetflixDemoApplication.class, args);
	}

}
