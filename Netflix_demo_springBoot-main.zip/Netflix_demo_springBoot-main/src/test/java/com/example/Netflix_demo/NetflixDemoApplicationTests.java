package com.example.Netflix_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
